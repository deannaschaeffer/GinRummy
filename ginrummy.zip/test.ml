open OUnit2
(* open Command *)
open Card
open Deckstack
open Playerhand
open State
open Autoplayer

(********************************************************************
   Here are some helper functions for your testing of set-like lists. 
 ********************************************************************)

(** [cmp_set_like_lists lst1 lst2] compares two lists to see whether
    they are equivalent set-like lists.  That means checking two things.
    First, they must both be {i set-like}, meaning that they do not
    contain any duplicates.  Second, they must contain the same elements,
    though not necessarily in the same order. *)
let cmp_set_like_lists lst1 lst2 =
  let uniq1 = List.sort_uniq compare lst1 in
  let uniq2 = List.sort_uniq compare lst2 in
  List.length lst1 = List.length uniq1
  &&
  List.length lst2 = List.length uniq2
  &&
  uniq1 = uniq2

(** [pp_string s] pretty-prints string [s]. *)
let pp_string s = "\"" ^ s ^ "\""

(** [pp_list pp_elt lst] pretty-prints list [lst], using [pp_elt]
    to pretty-print each element of [lst]. *)
let pp_list pp_elt lst =
  let pp_elts lst =
    let rec loop n acc = function
      | [] -> acc
      | [h] -> acc ^ pp_elt h
      | h1 :: (h2 :: t as t') ->
        if n = 100 then acc ^ "..."  (* stop printing long list *)
        else loop (n + 1) (acc ^ (pp_elt h1) ^ "; ") t'
    in loop 0 "" lst
  in "[" ^ pp_elts lst ^ "]"

(* These tests demonstrate how to use [cmp_set_like_lists] and 
   [pp_list] to get helpful output from OUnit. *)
let cmp_demo = 
  [
    "order is irrelevant" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          ["foo"; "bar"] ["bar"; "foo"]);
    (* Uncomment this test to see what happens when a test case fails.
       "duplicates not allowed" >:: (fun _ -> 
        assert_equal ~cmp:cmp_set_like_lists ~printer:(pp_list pp_string)
          ["foo"; "foo"] ["foo"]);
    *)
  ]

(********************************************************************
   End helper functions.
 ********************************************************************)

(* You are welcome to add strings containing JSON here, and use them as the
   basis for unit tests.  Or you can add .json files in this directory and
   use them, too.  Any .json files in this directory will be included
   by [make zip] as part of your CMS submission. *)

let card_tests =
  [

  ]

let c1 = {rank = 1; suit = HEARTS}
let c2 = {rank = 2; suit = CLUBS}
let c3 = {rank = 8; suit = HEARTS}
let d = [c1]

let deckstack_pop_test 
    (name : string) 
    (deck: Deckstack.deck)
    (input: Card.card) 
    (expected_output : Card.card) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (fst (pop (push input deck))))

let deck_compare a b =
  if a.rank > b.rank then 1 else if a.rank < b.rank then -1
  else if a.suit = HEARTS then 1 else if b.suit = HEARTS then -1
  else if a.suit = SPADES then 1 else if b.suit = SPADES then -1
  else if a.suit = CLUBS then 1 else if b.suit = CLUBS then -1 else 0

let deckstack_shuffle_test 
    (name : string) 
    (deck: Deckstack.deck)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output 
        (List.sort deck_compare (shuffle deck)
         = List.sort deck_compare deck))

let deckstack_shuffle2_test 
    (name : string) 
    (deck: Deckstack.deck)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output 
        (shuffle deck <>  deck))

let deckstack_empty_test 
    (name : string) 
    (deck: Deckstack.deck)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output 
        (is_empty deck))

let rec printlst l = 
  match l with
  | h :: t -> string_of_int h.rank ^ ";" ^ printlst t
  | [] -> ""

let rec printlsts ll = 
  match ll with
  | h :: t ->  "[" ^ printlst h ^ "]" ^ ";" ^ printlsts t
  | [] -> ""

let deckstack_intitialhands_test 
    (name : string) 
    (deck : Deckstack.deck)
    (num_players : int)
    (num_cards : int)
    (expected_output : Card.card list * Card.card list list) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (hands deck num_players num_cards) )
(* ~printer:printlsts) *)

let deck_a = [
  {rank = 9; suit = DIAMONDS};
  {rank = 10; suit = DIAMONDS};
  {rank = 11; suit = DIAMONDS};
  {rank = 2; suit = DIAMONDS};
  {rank = 3; suit = DIAMONDS};
  {rank = 4; suit = DIAMONDS};
  {rank = 5; suit = DIAMONDS};
  {rank = 9; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 11; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 9; suit = SPADES};
  {rank = 3; suit = CLUBS};
  {rank = 10; suit = SPADES};
  {rank = 4; suit = CLUBS};
  {rank = 7; suit = HEARTS};
  {rank = 5; suit = CLUBS};
  {rank = 6; suit = SPADES};
  {rank = 2; suit = CLUBS};
]

let hand1 = [
  {rank = 5; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 5; suit = DIAMONDS};
  {rank = 3; suit = DIAMONDS};
  {rank = 11; suit = DIAMONDS};
  {rank = 9; suit = DIAMONDS};
]

let hand2 = [
  {rank = 6; suit = HEARTS};
  {rank = 11; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 4; suit = DIAMONDS};
  {rank = 2; suit = DIAMONDS};
  {rank = 10; suit = DIAMONDS};
]

let remains = [
  {rank = 9; suit = SPADES};
  {rank = 3; suit = CLUBS};
  {rank = 10; suit = SPADES};
  {rank = 4; suit = CLUBS};
  {rank = 7; suit = HEARTS};
  {rank = 5; suit = CLUBS};
  {rank = 6; suit = SPADES};
  {rank = 2; suit = CLUBS};
]

let hand3 = [
  {rank = 7; suit = HEARTS};
  {rank = 3; suit = CLUBS};
  {rank = 5; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 5; suit = DIAMONDS};
  {rank = 2; suit = DIAMONDS};
  {rank = 9; suit = DIAMONDS};
]

let hand4 = [
  {rank = 5; suit = CLUBS};
  {rank = 10; suit = SPADES};
  {rank = 6; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 3; suit = DIAMONDS};
  {rank = 10; suit = DIAMONDS};
]

let hand5 = [
  {rank = 6; suit = SPADES};
  {rank = 4; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 11; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 4; suit = DIAMONDS};
  {rank = 11; suit = DIAMONDS};
]

let hand6 = [
  {rank = 6; suit = SPADES};
  {rank = 4; suit = CLUBS};
  {rank = 7; suit = SPADES};
  {rank = 11; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 4; suit = DIAMONDS};
  {rank = 11; suit = DIAMONDS};
  {rank = 8; suit = CLUBS};
]

let hand7 = [
  {rank = 9; suit = CLUBS};
  {rank = 12; suit = DIAMONDS};
  {rank = 9; suit = DIAMONDS};
  {rank = 4; suit = SPADES};
  {rank = 11; suit = DIAMONDS};
  {rank = 8; suit = DIAMONDS};
  {rank = 3; suit = HEARTS};
  {rank = 8; suit = SPADES};
]

let deckstack_tests =
  [
    deckstack_pop_test "push and pop" d c2 c2; 

    deckstack_shuffle_test "shuffle" deck_a true;
    deckstack_shuffle_test "shuffle" hand1 true;

    deckstack_shuffle2_test "shuffle2" deck_a true;
    deckstack_shuffle2_test "shuffle3" hand2 true;
    deckstack_shuffle2_test "shuffle4" hand1 true;

    deckstack_empty_test "empty" deck_a false;

    deckstack_intitialhands_test "initial" deck_a 2 7 (remains, [hand1; hand2]);
    deckstack_intitialhands_test "initial2" deck_a 3 7 ([c2], [hand3; hand4; hand5]);
  ]

let autoplayer_pickmed_test 
    (name : string) 
    (top : Card.card)
    (stock : Deckstack.deck)  
    (expected_output : int option) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (pick_med top stock) )
(* ~printer:printlsts) *)
let autoplayer_discardmed_test 
    (name : string) 
    (hand : Deckstack.deck)
    (hand_remains : Deckstack.deck)  
    (expected_output : int option) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (discard_med hand hand_remains))

(* ~printer:string_of_int_opt) *)

let autoplayer_tests = 
  [
    autoplayer_pickmed_test "pick from discard-same rank" c2 hand3 (Some 2);
    autoplayer_pickmed_test "pick from stock" c1 hand3 (Some 1);
    autoplayer_pickmed_test "pick from discard-consecutive suit" c3 hand3 (Some 2);

    autoplayer_discardmed_test "hand 6" hand6 hand6 (Some 1);
    autoplayer_discardmed_test "discard 1st w/o pair-5" remains remains (Some 2);
    autoplayer_discardmed_test "hand 7" hand7 hand7 (Some 2);
  ]

let check_consecutive_cards_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (check_consecutive cards)
    )
let check_same_rank_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (check_same_rank cards)
    )

let check_two_consecutive_groups_same_suit_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (check_two_consecutive_groups_same_suit cards)
    )

let check_three_consecutive_groups_same_suit_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (check_three_consecutive_groups_same_suit cards)
    )

let check_two_consecutive_groups_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (check_two_consecutive_groups cards)
    )

let check_three_consecutive_groups_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (check_three_consecutive_groups cards)
    )

let is_winning_hand_6_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (is_winning_hand_6 cards)
    )

let is_winning_hand_test
    (name : string) 
    (cards : Card.card list)
    (expected_output : bool) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (is_winning_hand cards)
    )

let d1 = [
  {rank = 3; suit = HEARTS};
  {rank = 4; suit = DIAMONDS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = DIAMONDS};
]
let d2 = [
  {rank = 3; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]
let d3 = [
  {rank = 3; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]
let d4 = [
  {rank = 9; suit = DIAMONDS};
  {rank = 10; suit = DIAMONDS};
  {rank = 11; suit = DIAMONDS};
  {rank = 12; suit = DIAMONDS};
]
let d5 = [
  {rank = 9; suit = DIAMONDS};
  {rank = 9; suit = HEARTS};
  {rank = 9; suit = CLUBS};
  {rank = 9; suit = SPADES};
]
let d6 = [
  {rank = 9; suit = DIAMONDS};
  {rank = 10; suit = DIAMONDS};
  {rank = 11; suit = DIAMONDS};
  {rank = 2; suit = DIAMONDS};
  {rank = 3; suit = DIAMONDS};
  {rank = 4; suit = DIAMONDS};
  {rank = 5; suit = DIAMONDS};
]
let d7 = [
  {rank = 9; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 11; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]
let d8 = [
  {rank = 9; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]

let d9 = [
  {rank = 11; suit = HEARTS};
  {rank = 13; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 12; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]
let d10 = [
  {rank = 8; suit = HEARTS};
  {rank = 11; suit = DIAMONDS};
  {rank = 10; suit = DIAMONDS};
  {rank = 12; suit = DIAMONDS};
  {rank = 7; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]
let d11 = [
  {rank = 4; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 8; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 10; suit = HEARTS};
]
let d12 = [
  {rank = 4; suit = HEARTS};
  {rank = 5; suit = DIAMONDS};
  {rank = 6; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 8; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 10; suit = HEARTS};
]
let d13 = [
  {rank = 0; suit = SPADES};
  {rank = 3; suit = SPADES};
  {rank = 11; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 2; suit = SPADES};
  {rank = 9; suit = CLUBS};
  {rank = 1; suit = SPADES};
]
let d14 = [
  {rank = 0; suit = CLUBS};
  {rank = 1; suit = CLUBS};
  {rank = 2; suit = SPADES};
  {rank = 7; suit = CLUBS};
  {rank = 8; suit = SPADES};
  {rank = 9; suit = SPADES};
  {rank = 10; suit = SPADES};
]
let d15 = [
  {rank = 9; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 11; suit = CLUBS};
  {rank = 12; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 9; suit = HEARTS};
]
let d16 = [
  {rank = 9; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 7; suit = CLUBS};
  {rank = 8; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 9; suit = HEARTS};
]
let d17 = [
  {rank = 9; suit = CLUBS};
  {rank = 12; suit = SPADES};
  {rank = 9; suit = HEARTS};
  {rank = 12; suit = DIAMONDS};
  {rank = 12; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 9; suit = DIAMONDS};
]
let d18 = [
  {rank = 8; suit = CLUBS};
  {rank = 12; suit = SPADES};
  {rank = 9; suit = HEARTS};
  {rank = 12; suit = DIAMONDS};
  {rank = 12; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 9; suit = DIAMONDS};
]
let d19 = [
  {rank = 8; suit = CLUBS};
  {rank = 7; suit = CLUBS};
  {rank = 9; suit = CLUBS};
  {rank = 6; suit = CLUBS};
  {rank = 5; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 9; suit = DIAMONDS};
]
let d20 = [
  {rank = 1; suit = HEARTS};
  {rank = 2; suit = CLUBS};
  {rank = 2; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 3; suit = CLUBS};
  {rank = 3; suit = SPADES};
  {rank = 3; suit = DIAMONDS};
]
let d21 = [
  {rank = 4; suit = CLUBS};
  {rank = 1; suit = CLUBS};
  {rank = 3; suit = CLUBS};
  {rank = 5; suit = CLUBS};
  {rank = 2; suit = CLUBS};
  {rank = 6; suit = CLUBS};
  {rank = 7; suit = CLUBS};
]
let d22 = [
  {rank = 4; suit = CLUBS};
  {rank = 1; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 3; suit = CLUBS};
  {rank = 5; suit = CLUBS};
  {rank = 2; suit = CLUBS};
  {rank = 9; suit = CLUBS};
  {rank = 6; suit = CLUBS};
  {rank = 7; suit = CLUBS};
  {rank = 8; suit = CLUBS};
]
let d23 = [
  {rank = 5; suit = CLUBS};
  {rank = 1; suit = CLUBS};
  {rank = 11; suit = CLUBS};
  {rank = 3; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 2; suit = CLUBS};
  {rank = 9; suit = CLUBS};
  {rank = 6; suit = CLUBS};
  {rank = 7; suit = CLUBS};
  {rank = 12; suit = CLUBS};
]
let d24 = [
  {rank = 5; suit = HEARTS};
  {rank = 1; suit = HEARTS};
  {rank = 11; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 2; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 12; suit = HEARTS};
]
let d25 = [
  {rank = 5; suit = SPADES};
  {rank = 1; suit = SPADES};
  {rank = 11; suit = SPADES};
  {rank = 3; suit = SPADES};
  {rank = 10; suit = SPADES};
  {rank = 2; suit = SPADES};
  {rank = 9; suit = SPADES};
  {rank = 6; suit = SPADES};
  {rank = 7; suit = SPADES};
  {rank = 8; suit = SPADES};
]
let d26 = [
  {rank = 5; suit = SPADES};
  {rank = 1; suit = SPADES};
  {rank = 11; suit = SPADES};
  {rank = 3; suit = SPADES};
  {rank = 12; suit = SPADES};
  {rank = 2; suit = SPADES};
  {rank = 9; suit = SPADES};
  {rank = 6; suit = SPADES};
  {rank = 7; suit = SPADES};
  {rank = 8; suit = SPADES};
]
let d27 = [
  {rank = 11; suit = SPADES};
  {rank = 10; suit = SPADES};
  {rank = 9; suit = SPADES};
  {rank = 5; suit = SPADES};
  {rank = 7; suit = SPADES};
  {rank = 4; suit = SPADES};
  {rank = 8; suit = SPADES};
  {rank = 3; suit = SPADES};
  {rank = 2; suit = SPADES};
  {rank = 1; suit = SPADES};
]
let d28 = [
  {rank = 11; suit = SPADES};
  {rank = 10; suit = SPADES};
  {rank = 9; suit = SPADES};
  {rank = 5; suit = SPADES};
  {rank = 7; suit = SPADES};
  {rank = 4; suit = SPADES};
  {rank = 8; suit = SPADES};
  {rank = 3; suit = SPADES};
  {rank = 2; suit = SPADES};
  {rank = 1; suit = SPADES};
]
let d29 = [
  {rank = 11; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 9; suit = CLUBS};
  {rank = 5; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 3; suit = SPADES};
  {rank = 2; suit = SPADES};
  {rank = 1; suit = SPADES};
]
let d30 = [
  {rank = 10; suit = CLUBS};
  {rank = 8; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 4; suit = SPADES};
  {rank = 11; suit = CLUBS};
  {rank = 6; suit = HEARTS};
  {rank = 3; suit = SPADES};
  {rank = 12; suit = CLUBS};
  {rank = 2; suit = SPADES};
  {rank = 1; suit = SPADES};
]
let d31 = [
  {rank = 10; suit = HEARTS};
  {rank = 8; suit = HEARTS};
  {rank = 7; suit = CLUBS};
  {rank = 4; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 6; suit = CLUBS};
  {rank = 3; suit = HEARTS};
  {rank = 5; suit = CLUBS};
  {rank = 2; suit = HEARTS};
  {rank = 11; suit = HEARTS};
]
let d32 = [
  {rank = 10; suit = CLUBS};
  {rank = 8; suit = HEARTS};
  {rank = 7; suit = CLUBS};
  {rank = 4; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 6; suit = CLUBS};
  {rank = 3; suit = HEARTS};
  {rank = 5; suit = CLUBS};
  {rank = 2; suit = HEARTS};
  {rank = 11; suit = HEARTS};
]
let d33 = [
  {rank = 10; suit = CLUBS};
  {rank = 8; suit = CLUBS};
  {rank = 7; suit = CLUBS};
  {rank = 4; suit = HEARTS};
  {rank = 9; suit = CLUBS};
  {rank = 6; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 5; suit = CLUBS};
  {rank = 2; suit = HEARTS};
  {rank = 11; suit = CLUBS};
]
let d34 = [
  {rank = 7; suit = HEARTS};
  {rank = 9; suit = SPADES};
  {rank = 3; suit = CLUBS};
  {rank = 10; suit = SPADES};
  {rank = 13; suit = SPADES};
  {rank = 2; suit = CLUBS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 11; suit = SPADES};
  {rank = 1; suit = CLUBS};
]
let d35 = [
  {rank = 10; suit = SPADES};
  {rank = 10; suit = HEARTS};
  {rank = 10; suit = DIAMONDS};
  {rank = 5; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 3; suit = HEARTS};

]
let d36 = [
  {rank = 3; suit = SPADES};
  {rank = 10; suit = SPADES};
  {rank = 10; suit = HEARTS};
  {rank = 3; suit = CLUBS};
  {rank = 10; suit = DIAMONDS};
  {rank = 3; suit = HEARTS};
]
let d37 = [
  {rank = 11; suit = DIAMONDS};
  {rank = 5; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 9; suit = DIAMONDS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = DIAMONDS};
]
let d38 = [
  {rank = 5; suit = SPADES};
  {rank = 5; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 5; suit = DIAMONDS};
  {rank = 3; suit = HEARTS};
  {rank = 5; suit = CLUBS};
]
let d39 = [
  {rank = 3; suit = SPADES};
  {rank = 3; suit = HEARTS};
  {rank = 3; suit = CLUBS};
  {rank = 2; suit = CLUBS};
  {rank = 4; suit = CLUBS};
  {rank = 5; suit = CLUBS};
]
let d40 = [
  {rank = 4; suit = DIAMONDS};
  {rank = 4; suit = SPADES};
  {rank = 4; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 4; suit = HEARTS};
  {rank = 11; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
]
let d41 = [
  {rank = 9; suit = HEARTS};
  {rank = 3; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 7; suit = DIAMONDS};
  {rank = 11; suit = HEARTS};
  {rank = 5; suit = DIAMONDS};
  {rank = 6; suit = DIAMONDS};
  {rank = 8; suit = DIAMONDS};
  {rank = 1; suit = HEARTS};
  {rank = 2; suit = HEARTS};
]
let d42 = [
  {rank = 8; suit = HEARTS};
  {rank = 11; suit = DIAMONDS};
  {rank = 3; suit = SPADES};
  {rank = 10; suit = DIAMONDS};
  {rank = 3; suit = HEARTS};
  {rank = 12; suit = DIAMONDS};
  {rank = 7; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 3; suit = DIAMONDS};
]
let d43 = [
  {rank = 8; suit = CLUBS};
  {rank = 8; suit = DIAMONDS};
  {rank = 8; suit = SPADES};
  {rank = 9; suit = DIAMONDS};
  {rank = 9; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 10; suit = HEARTS};
  {rank = 10; suit = DIAMONDS};
  {rank = 10; suit = SPADES};
  {rank = 10; suit = CLUBS};
]
let d44 = [
  {rank = 8; suit = CLUBS};
  {rank = 8; suit = DIAMONDS};
  {rank = 8; suit = SPADES};
  {rank = 9; suit = DIAMONDS};
  {rank = 9; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 10; suit = HEARTS};
  {rank = 10; suit = DIAMONDS};
  {rank = 10; suit = SPADES};
  {rank = 11; suit = CLUBS};
]
let d45 = [
  {rank = 4; suit = HEARTS};
  {rank = 5; suit = HEARTS};
  {rank = 6; suit = HEARTS};
  {rank = 7; suit = HEARTS};
  {rank = 8; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 10; suit = HEARTS};
  {rank = 10; suit = CLUBS};
  {rank = 10; suit = SPADES};
  {rank = 10; suit = DIAMONDS};
]
let d46 = [
  {rank = 9; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 11; suit = CLUBS};
  {rank = 12; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 8; suit = HEARTS};
  {rank = 8; suit = SPADES};
  {rank = 8; suit = DIAMONDS};
]
let d47 = [
  {rank = 9; suit = CLUBS};
  {rank = 10; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 7; suit = CLUBS};
  {rank = 8; suit = CLUBS};
  {rank = 9; suit = HEARTS};
  {rank = 9; suit = HEARTS};
  {rank = 11; suit = DIAMONDS};
  {rank = 11; suit = CLUBS};
  {rank = 11; suit = HEARTS};
]
let d48 = [
  {rank = 9; suit = CLUBS};
  {rank = 12; suit = SPADES};
  {rank = 9; suit = HEARTS};
  {rank = 12; suit = DIAMONDS};
  {rank = 12; suit = CLUBS};
  {rank = 9; suit = SPADES};
  {rank = 9; suit = DIAMONDS};
  {rank = 11; suit = CLUBS};
  {rank = 11; suit = HEARTS};
  {rank = 11; suit = DIAMONDS};
]
let d49 = [
  {rank = 1; suit = DIAMONDS};
  {rank = 2; suit = DIAMONDS};
  {rank = 4; suit = DIAMONDS};
  {rank = 3; suit = DIAMONDS};
  {rank = 3; suit = CLUBS};
  {rank = 3; suit = SPADES};
  {rank = 8; suit = DIAMONDS};
  {rank = 9; suit = CLUBS};
  {rank = 10; suit = HEARTS};
  {rank = 11; suit = SPADES};
]

let is_winning_hand_tests =
  [
    check_consecutive_cards_test "consecutive, not same suit" d1 false;
    check_consecutive_cards_test "consecutive, same suit" d2 true;
    check_consecutive_cards_test "nonconsecutive, same suit" d3 false;
    check_consecutive_cards_test "consecutive, same suit" d4 true;
    check_same_rank_test "same suit, diff rank" d4 false;
    check_same_rank_test "same suit, same rank" d5 true;
    check_same_rank_test "diff suit, same rank" d5 true;
    check_two_consecutive_groups_same_suit_test "valid 3 then 4" d6 true;
    check_two_consecutive_groups_same_suit_test "valid 4 then 3, out of order" d7 true;
    check_two_consecutive_groups_same_suit_test "2 in order, 5 in order" d8 false;
    check_two_consecutive_groups_same_suit_test "valid" d9 true;
    check_three_consecutive_groups_same_suit_test "valid in order " d22 true;
    check_three_consecutive_groups_same_suit_test "valid all broken" d23 true;
    check_three_consecutive_groups_same_suit_test "lower two together, upper separate" d24 true;
    check_three_consecutive_groups_same_suit_test "lower separate, upper two together" d25 true;
    check_three_consecutive_groups_same_suit_test "invalid" d26 false;
    check_three_consecutive_groups_same_suit_test "invalid" d27 false;
    check_two_consecutive_groups_test "valid" d10 true;
    check_two_consecutive_groups_test "valid" d11 true;
    check_two_consecutive_groups_test "invalid" d12 false;
    check_two_consecutive_groups_test "valid" d13 true;
    check_two_consecutive_groups_test "six cards" d21 true;
    check_three_consecutive_groups_test "all same suit" d22 true;
    check_three_consecutive_groups_test "all same suit 2" d23 true;
    check_three_consecutive_groups_test "all same suit 3" d24 true;
    check_three_consecutive_groups_test "all same suit 3" d25 true;
    check_three_consecutive_groups_test "all same suit false" d26 false;
    check_three_consecutive_groups_test "all same suit false 2" d27 false;
    check_three_consecutive_groups_test "three different suits some together" d29 true;
    check_three_consecutive_groups_test "three different suits all separate" d30 true; 
    check_three_consecutive_groups_test "two suits all together" d31 true;
    check_three_consecutive_groups_test "one suit is off" d32 false;
    check_three_consecutive_groups_test "all consecutive 5 and 5" d33 false;
    check_three_consecutive_groups_test "4 groups all split" d34 false;
    check_three_consecutive_groups_test "3 groups, two share suit" d41 true;
    is_winning_hand_6_test "diff type groups" d35 true;
    is_winning_hand_6_test "same type groups rank " d36 true;
    is_winning_hand_6_test "same type groups incremental" d37 true;
    is_winning_hand_6_test "diff types of groups, overlapping num" d38 true;
    is_winning_hand_6_test "close but one gap" d39 false;
    is_winning_hand_test "winning" d11 true;
    is_winning_hand_test "winning" d10 true;
    is_winning_hand_test "winning" d7 true;
    is_winning_hand_test "not winning" d12 false;
    is_winning_hand_test "not winning" d14 false;
    is_winning_hand_test "winning" d15 true;
    is_winning_hand_test "winning" d16 true;
    is_winning_hand_test "winning" d17 true;
    is_winning_hand_test "not winning" d18 false;
    is_winning_hand_test "not winning" d19 true;
    is_winning_hand_test "not winning" d20 false;
    is_winning_hand_test "winning consec 1" d23 true;
    is_winning_hand_test "winning consec 2" d24 true;
    is_winning_hand_test "winning consec 3" d25 true;
    is_winning_hand_test "winning consec 4" d29 true;
    is_winning_hand_test "winning consec 5" d30 true;
    is_winning_hand_test "valid" d40 true;
    is_winning_hand_test "valid" d41 true;
    is_winning_hand_test "straightforward mixed" d42 true;
    is_winning_hand_test "consecutive same rank groups" d43 true;
    is_winning_hand_test "slightly off consecutive same rank groups" d44 false;
    is_winning_hand_test "6 consecutive and 4 same rank at top" d45 true;
    is_winning_hand_test "random test" d46 true;
    is_winning_hand_test "random test with overlap" d47 true;
    is_winning_hand_test "random consecutive multiples" d48 true;
    is_winning_hand_test "twisted up" d49 false;
  ]

let playerhand_tests =
  [
    (* TODO: add tests for the State module here *)
  ]


(*
let player1 = {State.Player.hand = {Playerhand.deck = hand1;};name = "susie"}


let state1 = {  
player_turn = {"susie"};
  discard_deck : Deckstack.deck;
  stockpile: Deckstack.deck;
  players: player list;
  winner : result (* player's name  *)
}


let discard_test
    (name : string) 
    (state : State.t)
    (topcard : Card.card)
    (expected_output : State.t) : test = 
  name >:: (fun _ -> 
      assert_equal expected_output (discard state topcard))



let state_test = 
  [

  ]
*)

let suite =
  "test suite for A2"  >::: List.flatten [
    card_tests;
    deckstack_tests;
    playerhand_tests;
    is_winning_hand_tests;
    autoplayer_tests;
  ]

let _ = run_test_tt_main suite
