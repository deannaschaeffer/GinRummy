(**Deckstack module*)
open Card

type deck = Card.card list 

(* turns deck from list to stack *)
(* let create_stack d = 
   let rev = List.rev d in
   let s = Stack.create in
   let rec form_stack rev s = 
    match rev with 
    | [] -> s
    | h :: t -> form_stack t Stack.push h s  *)

(* possibility *)
let pop = function 
  | [] -> failwith "Empty"
  | h :: t -> (h, t)

(* pushes card c onto top of deck d *)
let push c d = 
  c :: d

(* peeks at value of top card of deck d (used for face up pile) *)
(* let peek d = Stack.peek c d  *)
let peek d = 
  match d with 
  | [] -> failwith "Empty"
  | h :: t -> print_card h

(* checks if deck is empty (for stock pile) *)
let is_empty d = 
  d = []

(* randomly shuffles deck d *)
let shuffle d = 
  Random.self_init();
  let rand_assign = List.map (fun x -> (Random.bits(), x)) d in 
  let sorted = List.sort compare rand_assign in 
  List.map (fun (z, y) -> y) sorted

(**[create n lsts] is a list of length n empty lists*)
let rec create n lsts =
  match n with 
  | 1 -> lsts
  | x -> create (n - 1) ([] :: lsts)

(**[find_min lsts min min_lst] is the list in [lsts] that is the minimum length*)
let rec find_min lsts min min_lst =
  match lsts with 
  | [] -> min_lst
  | h :: t -> if List.length h < min then find_min t (List.length h) h 
    else find_min t min min_lst

(**[prepend el lsts min num] is the list with [el] prepended to [min] in
   [lsts] *)
let rec prepend el lsts min num = 
  match lsts with 
  | h :: t -> if h = min && List.length h < num then (el :: min) :: t 
    else h :: (prepend el t min num)
  | [] -> lsts 

(**[split d lsts num_players deck_size num_cards] *)
let rec split d lsts num_players deck_size num_cards =
  let min = find_min lsts max_int [] in
  match d with
  | h :: t -> if deck_size - (num_cards * num_players) - 1 < List.length t  
    then split t (prepend h lsts min num_cards) num_players deck_size num_cards
    else (d, lsts)
  | [] -> ([], [])

(* tuple where second element is a list containing each player's initial hand 
   of 7 cards and first element is the remaining deck after dealing *)
let hands d num_players num_cards =
  let lst = [] in
  let lsts = create num_players [lst] in
  split d lsts num_players (List.length d) num_cards


