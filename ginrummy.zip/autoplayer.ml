(* autoplayer ml *)
open Deckstack
open Card

let global_rand = Random.self_init();;
(* picks randomly *)
let pick_easy =
  let pile = Random.int 2 in
  print_endline(string_of_int pile);
  Some (pile + 1)

(* discards randomly *)
let discard_easy num =
  let pile = Random.int num in
  print_endline(string_of_int pile);
  Some (pile + 1)

(* true (keep) if current card has at least 1 other of its kind or 
   1 other of its suit that is consecutive to it *)
let rec check_pairs card remain_hand =
  match remain_hand with 
  | [] -> false
  | h :: t -> if card.rank = h.rank || 
                 (card.suit = h.suit && (abs (card.rank - h.rank)) = 1) 
    then true else check_pairs card t

let pick_med top hand = 
  if check_pairs top hand then Some 2 else Some 1

let discard_med hand flip =
  let remain = List.rev flip in 
  let rec disc hand remain = 
    match remain with 
    | [] -> Some 1
    | h :: t -> if check_pairs h (List.filter (fun x -> x <> h) hand) 
      then disc hand t else Some (List.length hand - List.length t)
  in disc hand remain
