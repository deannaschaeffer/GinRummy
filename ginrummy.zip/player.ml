(**player module*)
open Deckstack

type hand = Deckstack.deck 

type score = int 