open Playerhand
open Deckstack
open Card
open ANSITerminal
open Autoplayer

type player = {
  hand : Playerhand.deck;
  name : string;
  wins: int;
}

type result = Some of string | None

type t = {
  player_turn : player;
  discard_deck : Deckstack.deck;
  stockpile: Deckstack.deck;
  players: player list;
  winner : result;(* player's name  *)
  rounds: int;
}

let pp_card c = string_of_int c.rank

let pp_player p = p.name
(** [pp_list pp_elt lst] pretty-prints list [lst], using [pp_elt]
    to pretty-print each element of [lst]. *)
let pp_list pp_elt lst =
  let pp_elts lst =
    let rec loop n acc = function
      | [] -> acc
      | [h] -> acc ^ pp_elt h
      | h1 :: (h2 :: t as t') ->
        if n = 100 then acc ^ "..."  (* stop printing long list *)
        else loop (n + 1) (acc ^ (pp_elt h1) ^ "; ") t'
    in loop 0 "" lst
  in "[" ^ pp_elts lst ^ "]"

let rec get_cards s num res =
  match num with
  | 0 -> res
  | _ -> get_cards s (num - 1) ({rank = num ; suit = s} :: res)

let standard_deck =
  (get_cards HEARTS 13 [])@(get_cards SPADES 13 [])@
  (get_cards DIAMONDS 13 [])@(get_cards CLUBS 13 [])

let rec make_play names decks result = 
  match (names, decks) with
  | (h_n::t_n, h_d::t_d) -> make_play t_n t_d ({hand = h_d; name = h_n; wins = 0}::result)
  | (_,_) -> result


let rec check_init_hands players =
  match players with 
  | [] -> ()
  | h :: t -> if (is_winning_hand h.hand) 
    then let () = print_endline(h.name^" is the winner. Lucky Draw!") in exit 0 
    else check_init_hands t

let intialize_game (names: string list) (num_cards: int) =
  let stock = shuffle standard_deck in
  let decks = hands stock (List.length names) num_cards in
  let remain_deck = fst decks in
  let popped_deck = pop remain_deck in
  let dis = push (fst popped_deck) [] in
  let new_stock = snd popped_deck in
  let players_init = make_play names (snd decks) [] in
  let () = check_init_hands players_init in

  {
    player_turn = List.nth players_init 0;
    discard_deck = dis;
    stockpile = new_stock;
    players = players_init;
    winner = None;
    rounds = 1;
  }


let rec edit_players_next_round decks players res =
  match players, decks with
  | (h::t, h_d::t_d) -> edit_players_next_round t_d t ({h with hand = h_d}::res)
  |(_,_) -> List.rev res


let reset_game state num_cards=
  let stock = shuffle standard_deck in
  let decks = hands stock (List.length state.players) (num_cards) in
  let remain_deck = fst decks in
  let popped_deck = pop remain_deck in
  let dis = push (fst popped_deck) [] in
  let new_stock = snd popped_deck in
  let players_new = edit_players_next_round (snd decks) state.players [] in
  {
    player_turn = List.nth players_new 0;
    discard_deck = dis;
    stockpile = new_stock;
    players = players_new;
    winner = None;
    rounds = state.rounds + 1;
  }


let rec edit_players players person new_hand win_num=
  List.map (fun x -> if x = person then {x with hand=new_hand; wins = win_num}
             else x) players

let rec get_new_player players name =
  match players with
  | [] -> raise (Failure "Not found")
  | h::t -> if h.name = name then h else get_new_player t name

let discard st card =
  let () = print_endline ("discarding " ^ string_of_int card.rank) in 
  let new_player_hand = remove_card card st.player_turn.hand in
  let new_players = edit_players st.players st.player_turn new_player_hand st.player_turn.wins in
  {
    st with discard_deck = push card st.discard_deck; 
            players = new_players;
            player_turn = get_new_player new_players st.player_turn.name
  }

(**[draw_helper st deck popped_deck] edits the new_player hand and adds the card
   they drew to their hand *)
let draw_helper st deck popped_deck=
  let new_player_hand = (fst popped_deck)::(st.player_turn.hand) in
  edit_players st.players st.player_turn new_player_hand st.player_turn.wins

let draw_from_discard st =
  let popped_deck = pop st.discard_deck in
  let new_players = draw_helper st st.discard_deck popped_deck in
  {st with discard_deck = snd popped_deck; 
           players = new_players; player_turn = get_new_player new_players
                                      st.player_turn.name} 

let draw_from_stockpile st =
  let popped_deck = pop st.stockpile in
  let new_players = draw_helper st st.stockpile popped_deck in
  {st with stockpile = snd popped_deck; 
           players = new_players; player_turn = get_new_player new_players
                                      st.player_turn.name } 

let reset_deck st =
  if is_empty st.stockpile then
    let new_stock = shuffle st.discard_deck in
    let popped_deck = pop new_stock in
    let new_discard = push (fst popped_deck) [] in
    {st with discard_deck = new_discard; stockpile = snd popped_deck}
  else st

let rec player_draw d st num=
  print_endline "Your cards currently are: ";
  print_all_cards st.player_turn.hand;
  print_endline("What would you like to do?\n
                1. Draw from stockpile\n
                2. Take the top card on the discard pile\n
                The top card on the discard pile is: \n");
  peek d; 
  print_endline("\nEnter the number of your choice: ");
  let decision = if st.player_turn.name = "easy autoplayer" then pick_easy
    else if st.player_turn.name = "medium autoplayer" 
    then pick_med (fst (pop d)) st.player_turn.hand
    else read_int_opt() in
  match decision with
  | Some 1 -> print_int 1; draw_from_stockpile st
  | Some 2 -> print_int 2; draw_from_discard st
  | _ ->begin
      print_endline("That's not a possible move. Do you want to quit? Type YES to quit or anything else to keep playing");
      let x = read_line() in if x = "YES" then
        let () = print_endline("GAME OVER. NO WINNER") 
        in exit 0  else erase Screen;
      player_draw d st num
    end


(**[player_cards cards st num] displays the [cards] and uses [st] to
   execute the player's turn based on the choices they enter
   Requires: [st] is state and [cards] is a card list *)
let rec player_cards cards st num=
  print_endline("Your Cards are: ");
  print_all_cards cards; 
  print_endline("What card would you like to discard? ");
  print_all_cards_nums cards num;
  print_endline("Enter the number of your choice: ");
  let decision = if st.player_turn.name = "easy autoplayer" then (discard_easy num)
    else if st.player_turn.name = "medium autoplayer" 
    then discard_med st.player_turn.hand st.player_turn.hand
    else read_int_opt() in
  match decision with
  | None -> erase Screen; print_endline("Invalid move. Try again.");
    player_cards cards st num
  | Some x -> begin print_int x; if num = 7 && x > 8 || num = 10 && x > 11 || x < 1
      then let () = erase Screen; print_endline("Invalid move. Try again.");
        in player_cards cards st num
      else discard st (List.nth (List.rev cards) (x-1)) end

(**[find_new_index_player p players ind player_count] is the index int of where the
   next player's turn index is from where [p] is in [players] and then wraps around
   if the next index is out of range*)
let rec find_new_index_player p players ind player_count=
  match players with 
  | [] -> raise (Failure "Not Found")
  | h :: t -> if h = p then ((ind + 1) mod player_count)
    else find_new_index_player p t (ind + 1) player_count 

let player_turn st num=
  print_endline ("\n"^st.player_turn.name ^ " it is your turn! \n");
  let check_reset_st = reset_deck st in
  let new_st = player_draw check_reset_st.discard_deck check_reset_st num in
  let make_move_state = player_cards new_st.player_turn.hand new_st num in
  let determine_winner = is_winning_hand make_move_state.player_turn.hand in
  let ind = find_new_index_player make_move_state.player_turn 
      make_move_state.players 0 (List.length make_move_state.players) in 
  if determine_winner = false then 
    {make_move_state with player_turn = List.nth make_move_state.players ind}
  else let new_player = make_move_state.player_turn in 
    let edit_player = { new_player with wins = new_player.wins + 1} in
    let new_players = edit_players make_move_state.players new_player new_player.hand (new_player.wins + 1) in
    {make_move_state with players = new_players; winner = Some edit_player.name; player_turn = edit_player}


let get_winner st =
  st.winner

let get_rounds st =
  st.rounds

let rec print_results_helper players =
  match players with
  | [] -> print_endline("");
  |h::t -> print_endline(h.name ^" won: "^(string_of_int h.wins)^" games "); print_results_helper t

let rec print_results st =
  print_endline("The results are: ");
  print_results_helper st.players