open State
open ANSITerminal
(** [play_game f] starts the adventure in file [f]. *)
exception Invalid 


(**[play_turn state num] is the game play of continuous player turns for a game
   with [num] cards until there is a winner. 
   The game is maintained and played through [state]. Once there is a winner
   the user is prompted if they want to play another round
   Requires: [state] is a state
          [num] is an int*)
let rec play_turn state num =
  let next_state = player_turn state num in 
  match get_winner next_state with 
  | None -> play_turn next_state num
  | Some winner -> begin 
      print_endline ("Congrats, " ^ winner ^ ", you've won!");
      let play_again state num_cards =
        print_endline("Do you want to play again? Type YES to play again");
        let x = read_line() in if x = "YES" then
          let new_game = reset_game state num_cards in
          print_endline ("ROUND "^string_of_int(get_rounds new_game));
          play_turn new_game num_cards
        else
          let () = print_endline("GAME OVER!"); 
          in  print_results state; exit 0;
      in
      play_again next_state num
    end

(**[autoplayer_level num] determines which level of autoplayer the
   user chose (1 =easy, 2=medium, 3=false). In the event that the player chooses a 
   number out of range the function calls itself
   Requires: [num] is an int*)
let rec autoplayer_level num =
  if num = 1 then 
    print_endline "What level of autoplayer do want? (1 = easy, 2 = medium, 3 = hard)";
  match read_int() with 
  | 1 -> "easy autoplayer"
  | 2 -> "medium autoplayer" 
  | 3 -> "hard autoplayer"
  | _ -> print_endline("Enter a valid option"); autoplayer_level 1

(**[get_names num] prompts the user to enter [num] number of player names
   and creates a string list of those names
   Requires: [num] is an int*)
let get_names num = 
  let rec action num acc count = 
    (* print_endline ("Enter the name of player number " ^ string_of_int count ^ "."); *)
    if num > 0 then 
      let q = print_endline 
          ("Enter the name of player number " ^ string_of_int count ^ ".") in
      match read_line () with
      | exception End_of_file -> []
      | name -> 
        if name = "" then action num acc count else 
          action (num - 1) (name::acc) (count + 1)
    else if num = 0 && List.length acc = 1 then
      let level = autoplayer_level 1 in
      level :: acc
    else
      acc 
  in 
  action num [] 1

(**[init_game num num_cards] prompts the user for [num] player's names and
   initialize a game with [num_cards] hands
   Requires: [num] and [num_cards] are ints  *)
let init_game num num_cards= 
  let names = get_names num in 
  let state = intialize_game names num_cards in 
  play_turn state num_cards


(**[get_ans message] prints [message] and then reads in user selection returing
   the int the user enters
   Requires: [message] is a string *)
let rec get_ans message = 
  print_endline message; 
  match read_int_opt() with 
  | Some x -> 
    if x <> 7 && x <> 10 then 
      get_ans "Invalid number of cards. Please enter either 7 or 10." 
    else x
  | None -> get_ans "Invalid number of cards. Please enter either 7 or 10."


(**[rules] is the string representation of the rules of Gin Rummy *)
let rules = "
  OPTIONS: The game can be played with 1 - 4 players. If you choose the option 
  for 1 player, you will be playing against an autoplayer. You can choose the 
  level of the autoplayer: easy, medium, or hard.
  Additionally, the game can be played with player hand sizes of either 7 or 10. 

  SETUP: A hand of the specified size (7 or 10 depending on game option) is dealt
  to each player initially. One card is flipped from the draw pile to the discard 
  pile face up and all cards remaining cards in the deck are placed face down
  in the draw pile. The first player who entered their name in game setup starts.

  ON YOUR TURN: On a player's turn, they have the choice between picking up the 
  top card in the discard pile (visible to them) or the top card in the draw pile
  (invisible to them). Then they must select a card in their current hand (including
  the card they just drew) to discard. This card gets placed face up as the new
  top card in the discard pile. The turn is now over.

  HOW TO WIN: A player has won when all 7 or 10 cards in their hand can be split 
  up into valid groups. A valid group is defined as a group of either three or 
  four cards that meets ONE of the following two criteria:
   1) all cards are of the same suit in consecutive order (i.e. a 5 of hearts, 6
   of hearts, 7 or hearts, and 8 of hearts) OR 
   2) all cards are of the same rank (i.e. a 6 of hearts, 6 of clubs, and 6 of 
   diamonds)

  NOTE ON VALUES: An ace is treated as a 1 and NOT a 14. Additionally, a Jack is 
  treated as value 11, a Queen is treated as value 12, and a King is treated as 
  value 13. For example, a 10 of spades, J of spades, Q of spades, and K of 
  spades is a valid hand, but a J of spades, Q of spades, K of spades, and A of 
  spades is not. You do not need to press anything when you think you have a win 
  - the game will automatically recognize your hand as a winner! 

  Good luck and have fun! 
  "
(**[rules_question] is the string representation asking whether the user
   knows the rules *)
let rules_question = 
  "Do you know the rules? Enter YES if you do. Enter anything else if you don't"


(** [main ()] prompts for the game to play, then starts it. *)
let main () =
  ANSITerminal.(print_string [red]
                  "\n\nWelcome to Gin Rummy.\n");
  print_endline(rules_question);
  let x = read_line() in if x <> "YES" then print_endline rules else 
    print_endline "Skipping Rules";
  let ans = get_ans "Would you like to play with 10 or 7-card hands?" in
  let rec get_numbers message = 
    print_endline message; 
    try 
      match read_int_opt() with 
      | Some x -> 
        if x > 4 || x < 1 then 
          get_numbers "Invalid number of players. Please enter a whole number between 1 and 4." 
        else init_game x ans
      | None -> raise Invalid 
    with 
    | Invalid -> 
      get_numbers "This isn't a valid number. Please enter a whole number between 1 and 4." 
    | x -> print_endline "errored getting number of players"
  in get_numbers "Enter number of players:"

(** Executes the game engine. *)
let () = main ()
